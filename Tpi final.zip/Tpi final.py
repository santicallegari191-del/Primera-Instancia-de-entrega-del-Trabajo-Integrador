def cargar_herramientas(inventario):
    """Opción 1: Carga múltiple de herramientas con existencias iniciales"""
    while True:
        try:
            cantidad = int(input("Ingrese cuántas herramientas desea cargar: "))
            if cantidad <= 0:
                raise ValueError("La cantidad debe ser mayor que 0.")
            break
        except ValueError as e:
            print(f"Error: {e}. Intente nuevamente.")

    for _ in range(cantidad):
        # Pedir y validar nombre
        while True:
            nombre = input("Ingrese el nombre de la herramienta: ").strip()
            if not nombre:
                print("Error: El nombre no puede estar vacío o compuesto solo por espacios.")
                continue
            # Verificar duplicados (ignorando mayúsculas/minúsculas)
            duplicado = False
            for prod in inventario:
                if prod['herramienta'].lower() == nombre.lower():
                    duplicado = True
                    break
            if duplicado:
                print(f"Error: La herramienta '{nombre}' ya se encuentra cargada.")
                continue
            break

        # Pedir y validar stock
        while True:
            try:
                stock = int(input(f"Ingrese el stock inicial para '{nombre}': "))
                if stock < 0:
                    raise ValueError("El stock no puede ser negativo.")
                break
            except ValueError as e:
                print(f"Error: {e}. Intente nuevamente.")

        # Agregar al inventario solo cuando ambos datos son válidos
        inventario.append({'herramienta': nombre, 'cantidad': stock})
        print(f"✅ Herramienta '{nombre}' cargada correctamente.")


def mostrar_inventario(inventario):
    """Opción 2: Muestra el listado completo de herramientas y su stock"""
    if not inventario:
        print("⚠️ Todavía no hay herramientas cargadas en el inventario.")
        return

    print("\n=== Inventario de Herramientas ===")
    for producto in inventario:
        print(f"- {producto['herramienta']}: {producto['cantidad']} unidades")
    print("===================================\n")


def consultar_stock(inventario):
    """Opción 3: Consulta el stock de una herramienta por nombre"""
    if not inventario:
        print("⚠️ Todavía no hay herramientas cargadas.")
        return

    nombre = input("Ingrese el nombre de la herramienta a consultar: ").strip()
    if not nombre:
        raise ValueError("El nombre no puede estar vacío.")

    for producto in inventario:
        if producto['herramienta'].lower() == nombre.lower():
            print(f"✅ Stock de '{producto['herramienta']}': {producto['cantidad']} unidades")
            return

    print(f"ℹ️ La herramienta '{nombre}' no se encuentra en el catálogo.")


def reporte_agotados(inventario):
    """Opción 4: Lista productos con stock igual a cero"""
    if not inventario:
        print("⚠️ Todavía no hay herramientas cargadas.")
        return

    agotados = [p for p in inventario if p['cantidad'] == 0]

    if not agotados:
        print("✅ Ninguna herramienta tiene stock cero en este momento.")
        return

    print("\n=== Herramientas Agotadas (Stock = 0) ===")
    for prod in agotados:
        print(f"- {prod['herramienta']}")
    print("==========================================\n")


def alta_producto(inventario):
    """Opción 5: Agrega una nueva herramienta con su stock inicial"""
    # Validar nombre
    nombre = input("Ingrese el nombre de la nueva herramienta: ").strip()
    if not nombre:
        raise ValueError("El nombre no puede estar vacío o con solo espacios.")

    # Verificar duplicados
    for prod in inventario:
        if prod['herramienta'].lower() == nombre.lower():
            raise ValueError(f"La herramienta '{nombre}' ya existe en el inventario.")

    # Validar stock
    stock = int(input(f"Ingrese el stock inicial para '{nombre}': "))
    if stock < 0:
        raise ValueError("El stock no puede ser negativo.")

    # Agregar si todo es válido
    inventario.append({'herramienta': nombre, 'cantidad': stock})
    print(f"✅ Herramienta '{nombre}' agregada correctamente con stock {stock}.")


def actualizar_stock(inventario):
    """Opción 6: Realiza venta o ingreso de unidades de una herramienta existente"""
    if not inventario:
        print("⚠️ Todavía no hay herramientas cargadas.")
        return

    # Validar nombre
    nombre = input("Ingrese el nombre de la herramienta: ").strip()
    if not nombre:
        raise ValueError("El nombre no puede estar vacío.")

    # Buscar herramienta
    producto_encontrado = None
    for prod in inventario:
        if prod['herramienta'].lower() == nombre.lower():
            producto_encontrado = prod
            break

    if not producto_encontrado:
        print(f"ℹ️ La herramienta '{nombre}' no existe en el inventario.")
        return

    # Tipo de movimiento
    tipo = input("Ingrese tipo de movimiento — 'venta' o 'ingreso': ").strip().lower()
    if tipo not in ('venta', 'ingreso'):
        print("⚠️ Tipo de movimiento inválido. Solo se aceptan 'venta' o 'ingreso'.")
        return

    # Unidades
    unidades = int(input("Ingrese la cantidad de unidades: "))
    if unidades <= 0:
        raise ValueError("Las unidades deben ser un número entero mayor que 0.")

    # Venta: verificar stock suficiente
    if tipo == 'venta':
        if producto_encontrado['cantidad'] < unidades:
            raise ValueError(f"Stock insuficiente. Disponibles: {producto_encontrado['cantidad']}, Solicitadas: {unidades}")
        producto_encontrado['cantidad'] -= unidades
        print(f"✅ Venta realizada. Stock actualizado: {producto_encontrado['cantidad']}")
    else:  # ingreso
        producto_encontrado['cantidad'] += unidades
        print(f"✅ Ingreso registrado. Stock actualizado: {producto_encontrado['cantidad']}")


def mostrar_menu():
    """Muestra las opciones disponibles del sistema"""
    print("\n" + "=" * 40)
    print("   SISTEMA DE CONTROL DE INVENTARIO")
    print("=" * 40)
    print("1. Cargar herramientas")
    print("2. Mostrar todo el inventario")
    print("3. Consultar stock de una herramienta")
    print("4. Reporte de herramientas agotadas")
    print("5. Agregar nueva herramienta")
    print("6. Actualizar stock (venta / ingreso)")
    print("7. Salir del sistema")
    print("=" * 40)


def main():
    inventario = []  # Estructura central: lista de diccionarios

    while True:
        mostrar_menu()
        try:
            opcion = int(input("Seleccione una opción [1-7]: "))

            if opcion == 1:
                cargar_herramientas(inventario)
            elif opcion == 2:
                mostrar_inventario(inventario)
            elif opcion == 3:
                consultar_stock(inventario)
            elif opcion == 4:
                reporte_agotados(inventario)
            elif opcion == 5:
                alta_producto(inventario)
            elif opcion == 6:
                actualizar_stock(inventario)
            elif opcion == 7:
                print("👋 Saliendo del sistema... ¡Hasta pronto!")
                break
            else:
                raise ValueError("Opción fuera de rango. Debe ser entre 1 y 7.")

        except ValueError as e:
            print(f"\n❌ Error: {e}")


if __name__ == "__main__":
    main()
